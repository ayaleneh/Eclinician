import java.time.LocalDate;
import java.time.Period;

public class MortgageCalculator {

    private static final double PARTNER_INCOME_FACTOR = 0.94;
    private static final int ADULT_AGE = 18;

    public double computeMaxMortgage(int yearOfBirth, int month, int day, double monthlyIncome, 
                                     boolean isMarried, double monthlyIncomePartner, String profession) {
        int age = calculateAge(yearOfBirth, month, day);

        double totalIncome = isMarried ? calculateTotalIncome(monthlyIncome, monthlyIncomePartner) : monthlyIncome;

        if (age < ADULT_AGE) {
            return 0;
        } else {
            return calculateLoanAmount(age, totalIncome, profession);
        }
    }

    private int calculateAge(int yearOfBirth, int month, int day) {
        LocalDate today = LocalDate.now();
        LocalDate birthday = LocalDate.of(yearOfBirth, month, day);
        return Period.between(birthday, today).getYears();
    }

    private double calculateTotalIncome(double monthlyIncome, double monthlyIncomePartner) {
        return monthlyIncome + monthlyIncomePartner * PARTNER_INCOME_FACTOR;
    }

    private double calculateLoanAmount(int age, double totalIncome, String profession) {
        if (totalIncome < 2000) {
            return 0;
        } else if (totalIncome < 3000) {
            return getLoanForIncomeBracket(profession, 160000, 120000, 220000);
        } else if (totalIncome < 5000) {
            return getLoanForIncomeBracket(profession, 180000, 140000, 250000);
        } else {
            return getLoanForIncomeBracket(profession, 220000, 160000, 280000);
        }
    }

    private double getLoanForIncomeBracket(String profession, double techLoan, double adminLoan, double managerLoan) {
        switch (profession) {
            case "Developer":
            case "Architect":
            case "Scrum master":
                return techLoan;
            case "Tester":
            case "System Administrator":
            case "Technical writer":
                return adminLoan;
            case "Department head":
            case "Professor":
                return managerLoan;
            default:
                return 0;
        }
    }
}