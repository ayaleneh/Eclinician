package application;

import products.Product;
import shoppingcart.ShoppingCart;

public class Application {

    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();

        Product tv = new Product("A123", 100.0, "TV");
        cart.addProduct(tv);

        Product mp3Player1 = new Product("A665", 75.0, "MP3 Player");
        cart.addProduct(mp3Player1);

        Product mp3Player2 = new Product("A665", 75.0, "MP3 Player");
        cart.addProduct(mp3Player2);

        cart.printCart();

        cart.removeProduct(mp3Player2);
        cart.removeProduct(mp3Player1);

        cart.printCart();
    }
}